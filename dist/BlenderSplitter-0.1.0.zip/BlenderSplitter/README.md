# BlenderSplitter

Distributed Tile Renderer Add-on for Blender 5.1.

## Features

- Auto startup networking: finds server over LAN (UDP discovery), otherwise starts own server.
- WebSocket-based server/worker communication.
- Adaptive tile split based on connected machine count.
- Configurable tile overlap (2-5%) for cleaner seams.
- Seam-aware stitching with weighted overlap blending.
- Render integrity check before tile render (camera/render/seed-related signature).
- Dry-run integrity check button before launching full render.
- Tile result return to server and final stitching.
- Retry/reassign when a worker disconnects or fails on a tile.
- Runtime metrics in panel (status, integrity, worker count, total time).
- Automatic project file sync to workers before distributed render.
- Auto-install missing requirements from the panel or at startup.
- Robust chunked tile transfer for large PNG tile results.
- Output run directories with `master` and `raw-splits` subfolders.
- Partition preview image opens in a dedicated new Blender window.
- Transfer metrics in UI (inline/chunked tile counts).

## V2 Robust Core

The codebase now includes a modular robust core:

- `robust_connection.py`: reconnect controller with retry/backoff policy.
- `robust_transfer.py`: chunker + assembler for large tile payloads.
- `robust_protocol.py`: message constants/builders for chunk transport.

This keeps networking, transfer, and recovery logic isolated and easier to harden.

## Install

1. Install Python dependencies into Blender's Python:

```bash
python -m pip install -r requirements.txt

import sys, subprocess
subprocess.check_call([sys.executable, "-m", "ensurepip", "--upgrade"])
subprocess.check_call([sys.executable, "-m", "pip", "install", "websockets", "pillow", "numpy"])
```

2. Zip this folder and install in Blender as Add-on.
3. Enable the add-on in Preferences.

## Build ZIP

Use the compile script to create an installable archive in `dist/`:

```bash
./compile.sh
```

## Usage

1. Open Sidebar in 3D View (`N`) -> Render tab -> Blender Splitter panel.
2. Click `Start Cluster` on each machine.
3. One machine becomes server automatically if no server is found.
4. Optional: click `Dry Run Integrity Check` on server machine.
5. On server machine, click `Distributed Render`.
6. Workers automatically:
   - Receive and extract project files
   - Open the project Blend file in Blender
   - Render assigned tiles
   - Return results to server
7. The final stitched output is written to the scene render output path.

### Output Layout

If `Output Folder` is set, each render run creates:

- `blendersplitter_<timestamp>/master` for final stitched render
- `blendersplitter_<timestamp>/raw-splits` for individual tile PNGs

## Project Sync (Large Projects)

If your Blender project is very large (> 512 MB), the add-on automatically:

- Splits the project into multiple zip parts (max 512 MB each by default)
- Sends parts sequentially to connected workers
- Workers reassemble and verify each part with SHA256 checksum
- Workers automatically open the synced Blend file in Blender
- Distributed render starts once all project files are ready
- Tile rendering happens in the worker's Blender instance

You can adjust the `max_mb` threshold in the manager if needed.

### Project Sync

- If `Auto Sync Project` is enabled, the server zips the current blend project directory and sends it to workers before rendering.
- Workers extract to a temp directory and acknowledge before tiles start.

### Auto Requirements

- On add-on startup, missing packages are installed automatically when possible.
- If `websockets` is missing during startup, it is auto-installed and reloaded automatically.
- You can also trigger installation manually with `Install Requirements` in the panel.

## Notes

- All workers must have same scene/camera/render setup for seamless stitching.
- If integrity check fails, tile is rejected and error is shown in panel.
- Current transport sends PNG data via Base64 over WebSocket.
