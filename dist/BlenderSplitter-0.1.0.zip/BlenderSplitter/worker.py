import asyncio
import base64
import hashlib
import importlib
import json
import random
import os
import queue
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import uuid
import zipfile

import bpy

from .network import DiscoveryResponder, discover_server, json_dumps
from .robust_connection import ReconnectController
from .robust_transfer import TileResultAssembler, TileResultChunker
from .stitch import stitch_tiles
from .tiles import collect_render_signature, generate_tiles, grid_for_worker_count, overlap_pixels

try:
	import websockets
except ImportError:
	websockets = None




def _load_websockets_module():
	global websockets
	try:
		websockets = importlib.import_module("websockets")
		return True
	except Exception:
		websockets = None
		return False


def _safe_scene():
	return bpy.context.scene if bpy.context else None


def _local_ip():
	import socket
	sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	try:
		sock.connect(("8.8.8.8", 80))
		return sock.getsockname()[0]
	except Exception:
		return "127.0.0.1"
	finally:
		sock.close()


class DistributedRenderManager:
	def __init__(self):
		self.node_id = str(uuid.uuid4())
		self.status = "Idle"
		self.role = "unassigned"
		self.last_error = ""
		self.last_integrity = "n/a"
		self.last_duration_seconds = 0.0
		self.server_host = ""
		self.server_port = 8765
		self.discovery_port = 8766
		self.overlap_percent = 3.0
		self.max_retries = 3
		self.auto_sync_project = True
		self.started = False

		self._task_queue = queue.Queue()
		self._result_queue = queue.Queue()
		self._progress_queue = queue.Queue()

		self._loop = None
		self._thread = None
		self._server = None
		self._discovery = None
		self._worker_socket = None
		self._stop_event = threading.Event()

		self.connected_workers = {}
		self.pending_jobs = {}
		self.completed_jobs = {}
		self.expected_jobs = 0
		self.current_render_config = None
		self.current_render_output = ""
		self.render_start_time = 0.0
		self.render_plan = []
		self.sync_total_bytes = 0
		self.sync_total_parts = 0
		self.job_owner = {}
		self.job_attempts = {}
		self.integrity_probe_results = {}
		self.project_sync_results = {}
		self.incoming_project_progress = {}
		self.received_project_dir = ""
		self.pending_project_load = None  # (project_dir, blend_file_name) to load in main thread
		self.output_dir = ""
		self.current_output_root = ""
		self.current_master_dir = ""
		self.current_raw_splits_dir = ""
		self._tile_chunker = TileResultChunker(chunk_size=512 * 1024, inline_limit=1024 * 1024)
		self._tile_assembler = TileResultAssembler()
		self._reconnect = ReconnectController(rediscover_after=3, self_host_after=8, max_sleep=2.5)
		self.transfer_stats = {
			"tiles_inline": 0,
			"tiles_chunked": 0,
			"chunk_messages": 0,
		}
		
		# Progress tracking for UI
		self.sync_progress = {}  # {worker_id: {"current_bytes": X, "total_bytes": Y, "part": Z, "status": "..."}}
		self.sync_active = False
		self.sync_successful = False
		self.sync_start_time = 0.0
		self.pending_render_after_sync = False
		self.pending_worker_sync_popup = False
		self.pending_worker_status_popup = False
		self.sync_total_bytes = 0
		self.sync_total_parts = 0
		self._loop_ready = threading.Event()
		self._server_ready = threading.Event()

		self._timer_registered = False

	def configure(
		self,
		host,
		server_port,
		discovery_port,
		overlap_percent=3.0,
		max_retries=3,
		auto_sync_project=True,
		show_render_window=True,
		server_render_tiles=True,
		output_dir="",
	):
		self.server_host = host
		self.server_port = int(server_port)
		self.discovery_port = int(discovery_port)
		self.overlap_percent = float(overlap_percent)
		self.max_retries = max(1, int(max_retries))
		self.auto_sync_project = bool(auto_sync_project)
		self.show_render_window = bool(show_render_window)
		self.server_render_tiles = bool(server_render_tiles)
		self.output_dir = bpy.path.abspath(output_dir) if output_dir else ""

	def _prepare_output_dirs(self, output_file):
		base = self.output_dir.strip() if self.output_dir else ""
		if not base:
			base = os.path.dirname(output_file) if output_file else tempfile.gettempdir()
		timestamp = time.strftime("%Y%m%d_%H%M%S")
		run_root = os.path.join(base, f"blendersplitter_{timestamp}")
		master_dir = os.path.join(run_root, "master")
		raw_dir = os.path.join(run_root, "raw-splits")
		os.makedirs(master_dir, exist_ok=True)
		os.makedirs(raw_dir, exist_ok=True)
		self.current_output_root = run_root
		self.current_master_dir = master_dir
		self.current_raw_splits_dir = raw_dir

	def start(self):
		if self.started:
			return
		if websockets is None:
			self.status = "websockets fehlt, starte Auto-Install"
			if not self.auto_install_requirements(only_modules=["websockets"]):
				if not _load_websockets_module():
					self.status = "websockets Paket fehlt"
					self.last_error = "Auto-Install fuer websockets fehlgeschlagen"
					return
			if not _load_websockets_module():
				self.status = "websockets Paket fehlt"
				self.last_error = "websockets konnte nach Installation nicht geladen werden"
				return

		self.started = True
		self._stop_event.clear()

		self._thread = threading.Thread(target=self._run_event_loop, daemon=True)
		self._thread.start()
		self._ensure_timer()

	def stop(self):
		self._stop_event.set()
		self.started = False
		self.status = "Gestoppt"
		if self._loop:
			try:
				asyncio.run_coroutine_threadsafe(self._shutdown_async(), self._loop)
			except RuntimeError:
				pass

	def force_start_server(self):
		"""Erzwingt Server-Modus (stoppt Worker-Verbindung)."""
		if not self.started:
			self.start()
		
		if not self._loop_ready.wait(timeout=3.0):
			self.last_error = "Server-Start konnte nicht initialisiert werden"
			self.status = self.last_error
			return False

		# Disconnect from any server and restart in server mode
		if self._loop:
			try:
				asyncio.run_coroutine_threadsafe(self._force_server_async(), self._loop)
				if not self._server_ready.wait(timeout=5.0):
					self.last_error = "Server hat nicht rechtzeitig geantwortet"
					self.status = self.last_error
					return False
				return True
			except RuntimeError:
				pass

		self.last_error = "Server-Loop ist nicht verfügbar"
		self.status = self.last_error
		return False
	
	async def _force_server_async(self):
		"""Async: Cleanup worker connection and force server start."""
		self._server_ready.clear()
		# Close worker connection
		if self._worker_socket is not None:
			try:
				await self._worker_socket.close()
			except Exception:
				pass
			self._worker_socket = None
		
		# Start server
		await self._start_server()
		self.status = f"Server erzwungen auf {self.server_host}:{self.server_port}"

	def _ensure_timer(self):
		if self._timer_registered:
			return

		def _tick():
			self.process_main_thread_queues()
			return 0.1 if self.started else None

		bpy.app.timers.register(_tick, persistent=True)
		self._timer_registered = True

	def process_main_thread_queues(self):
		# Auto-load pending project if received
		if self.pending_project_load:
			try:
				blend_file = self.pending_project_load
				self.status = f"Lade Projekt: {os.path.basename(blend_file)}"
				bpy.ops.wm.open_mainfile(filepath=blend_file)
				self.status = f"Projekt geladen: {os.path.basename(blend_file)}"
			except Exception as e:
				self.last_error = f"Projekt-Load fehlgeschlagen: {e}"
				self.status = self.last_error
			finally:
				self.pending_project_load = None

		while not self._progress_queue.empty():
			message = self._progress_queue.get_nowait()
			self.status = message

		while not self._task_queue.empty():
			item = self._task_queue.get_nowait()
			if item["type"] == "render_tile":
				result = self._render_tile_local(item["payload"])
				if item.get("reply_to") == "server_local":
					self._result_queue.put(result)
				else:
					self._send_result_to_server_async(result)

		while not self._result_queue.empty():
			result = self._result_queue.get_nowait()
			self._consume_tile_result(result)

		if self.pending_worker_sync_popup and self.sync_active:
			self.pending_worker_sync_popup = False
			# Popup auto-open disabled for stability; data remains visible in monitor UI.

		if self.pending_worker_status_popup and not self.sync_active:
			self.pending_worker_status_popup = False
			# Popup auto-open disabled for stability; data remains visible in monitor UI.

		if self.pending_render_after_sync and not self.sync_active:
			if self.sync_successful:
				self.pending_render_after_sync = False
				self.sync_successful = False
				self._begin_distributed_render()
			elif self.last_error or self.status.startswith("Projekt-Sync fehlgeschlagen"):
				self.pending_render_after_sync = False

	def _run_event_loop(self):
		self._loop = asyncio.new_event_loop()
		asyncio.set_event_loop(self._loop)
		self._loop_ready.set()
		self._loop.run_until_complete(self._auto_connect_or_host())
		self._loop.run_until_complete(self._main_loop())

	async def _main_loop(self):
		while not self._stop_event.is_set():
			await asyncio.sleep(0.25)
		await self._shutdown_async()

	async def _auto_connect_or_host(self):
		self.status = "Suche Server im Netzwerk..."

		# Avoid split-brain: try discovery multiple times before self-hosting.
		max_attempts = 6
		for attempt in range(max_attempts):
			found = discover_server(self.discovery_port, timeout=2.5)
			if found:
				host, port = found
				self.role = "worker"
				self.status = f"Server gefunden: {host}:{port}"
				await self._connect_as_worker(host, int(port))
				return

			self.status = f"Suche Server... ({attempt + 1}/{max_attempts})"
			await asyncio.sleep(0.6 + random.random() * 0.5)

		# Jitter before self-hosting so multiple nodes don't become server simultaneously.
		await asyncio.sleep(0.5 + random.random() * 1.5)

		# Final double-check right before starting server.
		found = discover_server(self.discovery_port, timeout=2.5)
		if found:
			host, port = found
			self.role = "worker"
			self.status = f"Server spät gefunden: {host}:{port}"
			await self._connect_as_worker(host, int(port))
			return

		self.status = "Kein Server gefunden, starte lokalen Server"
		await self._start_server()

	async def _shutdown_async(self):
		self._server_ready.clear()
		if self._worker_socket is not None:
			try:
				await self._worker_socket.close()
			except Exception:
				pass
			self._worker_socket = None

		if self._server is not None:
			self._server.close()
			await self._server.wait_closed()
			self._server = None

		if self._discovery is not None:
			self._discovery.stop()
			self._discovery = None

	async def _start_server(self):
		if self._server is not None:
			self.status = f"Server aktiv auf {self.server_host}:{self.server_port}"
			self._server_ready.set()
			return

		if self._worker_socket is not None:
			try:
				await self._worker_socket.close()
			except Exception:
				pass
			self._worker_socket = None

		self.role = "server"
		self.connected_workers = {}
		self.pending_jobs = {}
		self.completed_jobs = {}
		self.job_owner = {}
		self.job_attempts = {}
		self.expected_jobs = 0

		# ensure server_host is a usable local ip for display
		try:
			self.server_host = _local_ip()
		except Exception:
			pass

		bind_host = "0.0.0.0"
		self._server = await websockets.serve(
			self._handle_worker_socket,
			bind_host,
			self.server_port,
			ping_interval=20,
			ping_timeout=20,
			max_size=None,
		)
		self._discovery = DiscoveryResponder(self.discovery_port, self.server_port)
		self._discovery.start()
		self.status = f"Server aktiv auf {self.server_host}:{self.server_port}"
		self._server_ready.set()

	async def _connect_as_worker(self, host, port):
		host = str(host)
		port = int(port)
		url = f"ws://{host}:{port}"
		self._reconnect.reset()
		while not self._stop_event.is_set():
			try:
				async with websockets.connect(url, ping_interval=60, ping_timeout=120, max_size=None, open_timeout=5) as ws:
					self._reconnect.reset()
					self._worker_socket = ws
					self.server_host = host
					self.server_port = port
					self.status = f"Verbunden als Worker: {host}:{port}"
					self.pending_worker_status_popup = True
					await ws.send(
						json_dumps(
							{
								"type": "register_worker",
								"node_id": self.node_id,
								"app": bpy.app.version_string,
							}
						)
					)
					async for raw in ws:
						# handle binary chunk frames when acting as worker client
						if isinstance(raw, (bytes, bytearray)):
							# same logic as server-side: append to incoming project if present
							if hasattr(self, "_incoming_project") and self._incoming_project:
								with open(self._incoming_project["tmp_zip"], "ab") as fh:
									fh.write(raw)
								self._incoming_project.setdefault("received_bytes", 0)
								self._incoming_project["received_bytes"] += len(raw)
								self.incoming_project_progress = {
									"status": "Herunterladen",
									"current_bytes": self._incoming_project["received_bytes"],
									"total_bytes": self._incoming_project.get("total_size", 0),
									"part_index": self._incoming_project.get("part_index", 0),
									"total_parts": self._incoming_project.get("total_parts", 1),
									"project_name": self._incoming_project.get("project_name", ""),
								}
								if self._incoming_project.get("received_bytes", 0) >= self._incoming_project.get("total_size", 0):
									# finalize and send ack back to server
									part_idx = int(self._incoming_project.get("part_index", 0))
									res = self._finalize_received_project(
										self._incoming_project["tmp_zip"],
										self._incoming_project.get("zip_sha256"),
										{"file_count": self._incoming_project.get("file_count", 0), "project_name": self._incoming_project.get("project_name")},
									)
									res["part_index"] = part_idx
									await ws.send(json_dumps(res))
									self._incoming_project = None
									self.incoming_project_progress = {}
									self.pending_worker_status_popup = True
							continue
						msg = json.loads(raw)
						await self._handle_worker_message(ws, msg)
			except Exception as exc:
				fails = self._reconnect.on_failure()
				err = str(exc)
				self.last_error = err
				if "Errno 61" in err or "Connect call failed" in err:
					self.status = f"Server nicht erreichbar ({host}:{port}), erneute Suche..."
				else:
					self.status = f"Verbindung verloren, reconnect... ({err})"

				# rediscover after repeated failures; switch target if changed.
				if self._reconnect.should_rediscover():
					found = discover_server(self.discovery_port, timeout=1.5)
					if found:
						new_host, new_port = found
						new_host = str(new_host)
						new_port = int(new_port)
						if new_host != host or new_port != port:
							host = new_host
							port = new_port
							url = f"ws://{host}:{port}"
							self.status = f"Neuer Server gefunden: {host}:{port}"
							self._reconnect.reset()

				# no server reachable for a while -> recover by hosting locally
				if self._reconnect.should_self_host():
					self.status = "Kein erreichbarer Server, starte lokalen Server"
					await self._start_server()
					return

				await asyncio.sleep(self._reconnect.sleep_seconds())

	async def _handle_worker_socket(self, websocket):
		worker_id = None
		try:
			async for raw in websocket:
				# support binary chunks (project sync streaming)
				if isinstance(raw, (bytes, bytearray)):
					# append to incoming tmp zip if present
					if hasattr(self, "_incoming_project") and self._incoming_project:
						with open(self._incoming_project["tmp_zip"], "ab") as fh:
							fh.write(raw)
						self._incoming_project.setdefault("received_bytes", 0)
						self._incoming_project["received_bytes"] += len(raw)
						# finalize if enough bytes received
						if self._incoming_project.get("received_bytes", 0) >= self._incoming_project.get("total_size", 0):
							part_idx = int(self._incoming_project.get("part_index", 0))
							res = self._finalize_received_project(
								self._incoming_project["tmp_zip"],
								self._incoming_project.get("zip_sha256"),
								{"file_count": self._incoming_project.get("file_count", 0), "project_name": self._incoming_project.get("project_name")},
							)
							res["part_index"] = part_idx
							await websocket.send(json_dumps(res))
							self._incoming_project = None
							self.incoming_project_progress = {}
							self.pending_worker_status_popup = True
					continue
				# otherwise assume text/json
				msg = json.loads(raw)
				msg_type = msg.get("type")

				if msg_type == "register_worker":
					worker_id = msg.get("node_id") or str(uuid.uuid4())
					self.connected_workers[worker_id] = {
						"socket": websocket,
						"app": msg.get("app", "unknown"),
						"last_seen": time.time(),
					}
					await websocket.send(json_dumps({"type": "registered", "node_id": worker_id}))
					self.status = f"Worker verbunden: {len(self.connected_workers)}"

				elif msg_type == "tile_result":
					self._result_queue.put(msg)

				elif msg_type == "tile_result_start":
					assembled = self._tile_assembler.handle(msg)
					if assembled:
						self._result_queue.put(assembled)

				elif msg_type == "tile_result_chunk":
					assembled = self._tile_assembler.handle(msg)
					if assembled:
						self._result_queue.put(assembled)

				elif msg_type == "tile_result_complete":
					assembled = self._tile_assembler.handle(msg)
					if assembled:
						self._result_queue.put(assembled)

				elif msg_type == "integrity_probe_result":
					wid = msg.get("worker_id")
					if wid:
						self.integrity_probe_results[wid] = msg

				elif msg_type == "project_sync_ack":
					wid = msg.get("worker_id")
					if wid:
						# track ack per part_index to support multi-part bundles
						part_idx = int(msg.get("part_index", 0))
						self.project_sync_results.setdefault(wid, {})
						self.project_sync_results[wid][part_idx] = msg

				elif msg_type == "heartbeat":
					if worker_id and worker_id in self.connected_workers:
						self.connected_workers[worker_id]["last_seen"] = time.time()
		except Exception as exc:
			self.last_error = str(exc)
		finally:
			if worker_id and worker_id in self.connected_workers:
				self._reassign_jobs_from_worker(worker_id)
				del self.connected_workers[worker_id]
				self.status = f"Worker getrennt: {len(self.connected_workers)}"

	async def _handle_worker_message(self, websocket, msg):
		msg_type = msg.get("type")
		if msg_type == "registered":
			self.status = "Worker bereit"
			return

		if msg_type == "render_tile":
			self._task_queue.put({"type": "render_tile", "payload": msg})
			return

		if msg_type == "integrity_probe":
			scene = _safe_scene()
			local_signature = None
			if scene is not None:
				_, local_signature = collect_render_signature(scene)
			await websocket.send(
				json_dumps(
					{
						"type": "integrity_probe_result",
						"worker_id": self.node_id,
						"ok": local_signature == msg.get("render_signature"),
						"local_signature": local_signature,
						"expected_signature": msg.get("render_signature"),
					}
				)
			)
			return

		# Project sync streaming: start/chunk messages handled here on worker
		if msg_type == "project_sync_start":
			meta = msg
			root = os.path.join(tempfile.gettempdir(), "blender_splitter_projects")
			os.makedirs(root, exist_ok=True)
			part_idx = int(meta.get("part_index", 0))
			total_parts = int(meta.get("total_parts", 1))
			tmp_zip = os.path.join(root, f"incoming_{meta.get('zip_sha256')[:12]}_part{part_idx}.zip")
			self.sync_active = True
			self.pending_worker_sync_popup = True
			self.incoming_project_progress = {
				"status": "Warte auf Daten",
				"current_bytes": 0,
				"total_bytes": int(meta.get("total_size", 0)),
				"part_index": part_idx,
				"total_parts": total_parts,
				"project_name": meta.get("project_name", ""),
			}
			# reset incoming state for this part
			self._incoming_project = {
				"tmp_zip": tmp_zip,
				"zip_sha256": meta.get("zip_sha256"),
				"part_index": part_idx,
				"total_parts": total_parts,
				"total_size": int(meta.get("total_size", 0)),
				"received_bytes": 0,
			}
			# ensure file empty
			open(tmp_zip, "wb").close()
			return

		if msg_type == "project_sync_chunk":
			if not hasattr(self, "_incoming_project") or not self._incoming_project:
				# unexpected chunk
				return
			# legacy text-based chunk support (normally unused with binary streaming)
			chunk_idx = int(msg.get("index", 0))
			data_b64 = msg.get("data")
			if not data_b64:
				return
			try:
				data = base64.b64decode(data_b64)
			except Exception:
				return
			with open(self._incoming_project["tmp_zip"], "ab") as fh:
				fh.write(data)
			self._incoming_project["received_bytes"] += len(data)
			self.incoming_project_progress = {
				"status": "Herunterladen",
				"current_bytes": self._incoming_project["received_bytes"],
				"total_bytes": self._incoming_project.get("total_size", 0),
				"part_index": self._incoming_project.get("part_index", 0),
				"total_parts": self._incoming_project.get("total_parts", 1),
				"project_name": self._incoming_project.get("project_name", ""),
			}
			# if complete by bytes, finalize
			if self._incoming_project.get("total_size", 0) and self._incoming_project["received_bytes"] >= self._incoming_project["total_size"]:
				res = self._finalize_received_project(self._incoming_project["tmp_zip"], self._incoming_project["zip_sha256"], msg)
				# include part index in ack
				res["part_index"] = int(self._incoming_project.get("part_index", 0))
				# send ack to server
				await websocket.send(json_dumps(res))
				self._incoming_project = None
				self.incoming_project_progress = {}
				self.sync_active = False
			return

		if msg_type == "sync_project":
			self._task_queue.put({"type": "sync_project", "payload": msg})
			return

		if msg_type == "ping":
			await websocket.send(json_dumps({"type": "heartbeat", "node_id": self.node_id}))

	def _render_tile_local(self, payload):
		scene = _safe_scene()
		if scene is None:
			return {
				"type": "tile_result",
				"tile_id": payload.get("tile_id"),
				"ok": False,
				"error": "Keine aktive Szene",
			}

		_, local_sig = collect_render_signature(scene)
		expected_sig = payload.get("render_signature")
		if expected_sig != local_sig:
			self.last_integrity = "fehlgeschlagen"
			return {
				"type": "tile_result",
				"tile_id": payload.get("tile_id"),
				"ok": False,
				"error": "Integritaetscheck fehlgeschlagen",
				"local_signature": local_sig,
				"expected_signature": expected_sig,
			}

		self.last_integrity = "ok"
		tile = payload["tile"]
		out_path = self._render_tile_to_path(scene, tile)

		with open(out_path, "rb") as fh:
			encoded = base64.b64encode(fh.read()).decode("ascii")

		return {
			"type": "tile_result",
			"tile_id": payload["tile_id"],
			"ok": True,
			"worker_id": self.node_id,
			"tile": tile,
			"file_name": os.path.basename(out_path),
			"png_base64": encoded,
		}

	def _render_tile_to_path(self, scene, tile):
		render = scene.render
		original = {
			"use_border": render.use_border,
			"use_crop_to_border": render.use_crop_to_border,
			"border_min_x": render.border_min_x,
			"border_max_x": render.border_max_x,
			"border_min_y": render.border_min_y,
			"border_max_y": render.border_max_y,
			"filepath": render.filepath,
		}

		width = max(1, int(render.resolution_x * (render.resolution_percentage / 100.0)))
		height = max(1, int(render.resolution_y * (render.resolution_percentage / 100.0)))

		render.use_border = True
		render.use_crop_to_border = True
		render.border_min_x = tile["min_x"] / width
		render.border_max_x = tile["max_x"] / width
		render.border_min_y = tile["min_y"] / height
		render.border_max_y = tile["max_y"] / height

		tmp_dir = os.path.join(tempfile.gettempdir(), "blender_splitter_tiles")
		os.makedirs(tmp_dir, exist_ok=True)
		path = os.path.join(tmp_dir, f"tile_{tile['id']}_{uuid.uuid4().hex}.png")
		render.filepath = path

		try:
			bpy.ops.render.render(write_still=True, use_viewport=False)
		finally:
			render.use_border = original["use_border"]
			render.use_crop_to_border = original["use_crop_to_border"]
			render.border_min_x = original["border_min_x"]
			render.border_max_x = original["border_max_x"]
			render.border_min_y = original["border_min_y"]
			render.border_max_y = original["border_max_y"]
			render.filepath = original["filepath"]

		return path

	def _send_result_to_server_async(self, result):
		if self._loop is None or self._worker_socket is None:
			return

		async def _send():
			try:
				if not result.get("ok") or "png_base64" not in result:
					await self._worker_socket.send(json_dumps(result))
					return

				png_b64 = result.get("png_base64") or ""
				if not self._tile_chunker.needs_chunking(png_b64):
					self.transfer_stats["tiles_inline"] = int(self.transfer_stats.get("tiles_inline", 0)) + 1
					await self._worker_socket.send(json_dumps(result))
					return

				transfer_id = uuid.uuid4().hex
				chunk_msgs = self._tile_chunker.build_messages(result, transfer_id=transfer_id)
				self.transfer_stats["tiles_chunked"] = int(self.transfer_stats.get("tiles_chunked", 0)) + 1
				self.transfer_stats["chunk_messages"] = int(self.transfer_stats.get("chunk_messages", 0)) + len(chunk_msgs)
				for msg in chunk_msgs:
					await self._worker_socket.send(json_dumps(msg))
			except Exception as exc:
				self.last_error = str(exc)

		asyncio.run_coroutine_threadsafe(_send(), self._loop)

	def _send_project_sync_ack_async(self, result):
		if self._loop is None or self._worker_socket is None:
			return

		async def _send():
			try:
				await self._worker_socket.send(json_dumps(result))
			except Exception as exc:
				self.last_error = str(exc)

		asyncio.run_coroutine_threadsafe(_send(), self._loop)

	def _build_project_bundle(self, max_mb=512):
		blend_path = bpy.data.filepath
		if not blend_path:
			raise RuntimeError("Bitte zuerst .blend Datei speichern, damit Projekt-Sync moeglich ist")

		project_root = os.path.dirname(blend_path)
		blend_name = os.path.basename(blend_path)
		# Build one or more zip parts each not exceeding max_mb. Return parts metadata.
		max_bytes = int(max_mb * 1024 * 1024)

		# Collect candidate files first (relative paths)
		files_to_add = []
		total_bytes = 0
		for root, dirs, files in os.walk(project_root):
			dirs[:] = [d for d in dirs if d not in {".git", "dist", "__pycache__"}]
			for name in files:
				if name.endswith(".pyc") or name == ".DS_Store":
					continue
				path = os.path.join(root, name)
				rel = os.path.relpath(path, project_root)
				size = os.path.getsize(path)
				files_to_add.append((path, rel, size))
				total_bytes += size

		if not files_to_add:
			raise RuntimeError("Keine Projektdateien gefunden zum Sync")

		parts = []
		part_index = 0
		current_part_files = []
		current_part_bytes = 0
		current_part_count = 0

		def _flush_part():
			nonlocal part_index, current_part_files, current_part_bytes, current_part_count
			if not current_part_files:
				return
			buf = tempfile.NamedTemporaryFile(prefix=f"blendersplitter_part_{part_index}_", suffix=".zip", delete=False)
			buf.close()
			with zipfile.ZipFile(buf.name, "w", compression=zipfile.ZIP_DEFLATED) as zf:
				for p, rel, _ in current_part_files:
					zf.write(p, arcname=rel)
			with open(buf.name, "rb") as fh:
				data = fh.read()
			sha = hashlib.sha256(data).hexdigest()
			parts.append({
				"zip_path": buf.name,
				"zip_sha256": sha,
				"part_index": part_index,
				"file_count": current_part_count,
				"total_bytes": current_part_bytes,
			})
			part_index += 1
			current_part_files = []
			current_part_bytes = 0
			current_part_count = 0

		for path, rel, size in files_to_add:
			# if single file larger than max_bytes, still put in its own part
			if current_part_files and (current_part_bytes + size) > max_bytes:
				_flush_part()
			current_part_files.append((path, rel, size))
			current_part_bytes += size
			current_part_count += 1

		# flush final part
		_flush_part()

		total_parts = len(parts)
		# annotate total_parts and project meta
		for p in parts:
			p["total_parts"] = total_parts
			p["project_name"] = os.path.basename(project_root)
			p["blend_file"] = blend_name

		return {
			"parts": parts,
			"project_name": os.path.basename(project_root),
			"blend_file": blend_name,
			"total_bytes": total_bytes,
			"total_parts": total_parts,
		}

	def _apply_project_bundle(self, payload):
		try:
			encoded = payload["zip_base64"]
			data = base64.b64decode(encoded)
			sha = hashlib.sha256(data).hexdigest()
			if sha != payload.get("zip_sha256"):
				raise RuntimeError("Projektbundle Checksum stimmt nicht")

			root = os.path.join(tempfile.gettempdir(), "blender_splitter_projects")
			os.makedirs(root, exist_ok=True)
			target_dir = os.path.join(root, payload.get("project_name", "project") + "_" + sha[:8])
			os.makedirs(target_dir, exist_ok=True)

			tmp_zip = os.path.join(root, f"project_{sha[:12]}.zip")
			with open(tmp_zip, "wb") as fh:
				fh.write(data)
			with zipfile.ZipFile(tmp_zip, "r") as zf:
				zf.extractall(target_dir)
			os.unlink(tmp_zip)

			self.received_project_dir = target_dir
			self.pending_worker_status_popup = True
			self.sync_active = False
			
			# Find .blend file
			blend_file_path = None
			blend_file_name = payload.get("blend_file")
			if blend_file_name:
				test_path = os.path.join(target_dir, blend_file_name)
				if os.path.exists(test_path):
					blend_file_path = test_path
			
			if not blend_file_path:
				for root_dir, dirs, files in os.walk(target_dir):
					for f in files:
						if f.endswith(".blend"):
							blend_file_path = os.path.join(root_dir, f)
							break
					if blend_file_path:
						break
			
			if blend_file_path:
				self.pending_project_load = blend_file_path
				
			self.status = f"Projekt empfangen: {payload.get('file_count', 0)} Dateien"
			return {
				"type": "project_sync_ack",
				"worker_id": self.node_id,
				"ok": True,
				"project_dir": target_dir,
				"blend_file": blend_file_path,
			}
		except Exception as exc:
			self.last_error = f"Projekt-Sync fehlgeschlagen: {exc}"
			return {
				"type": "project_sync_ack",
				"worker_id": self.node_id,
				"ok": False,
				"error": str(exc),
			}

	def _finalize_received_project(self, tmp_zip, expected_sha, payload_meta=None):
		"""Verify zip, extract and return ack dict with blend file path."""
		try:
			with open(tmp_zip, "rb") as fh:
				data = fh.read()
			sha = hashlib.sha256(data).hexdigest()
			if sha != expected_sha:
				raise RuntimeError("Projektbundle Checksum stimmt nicht")

			root = os.path.join(tempfile.gettempdir(), "blender_splitter_projects")
			os.makedirs(root, exist_ok=True)
			target_dir = os.path.join(root, (payload_meta.get("project_name") if payload_meta else "project") + "_" + sha[:8])
			os.makedirs(target_dir, exist_ok=True)

			tmp_zip_dest = os.path.join(root, f"project_{sha[:12]}.zip")
			with open(tmp_zip_dest, "wb") as fh:
				fh.write(data)
			with zipfile.ZipFile(tmp_zip_dest, "r") as zf:
				zf.extractall(target_dir)
			os.unlink(tmp_zip_dest)

			self.received_project_dir = target_dir
			self.pending_worker_status_popup = True
			self.sync_active = False
			
			# Find .blend file in project
			blend_file_name = payload_meta.get("blend_file") if payload_meta else None
			blend_file_path = None
			
			if blend_file_name:
				test_path = os.path.join(target_dir, blend_file_name)
				if os.path.exists(test_path):
					blend_file_path = test_path
			
			# Fallback: search for any .blend file
			if not blend_file_path:
				for root_dir, dirs, files in os.walk(target_dir):
					for f in files:
						if f.endswith(".blend"):
							blend_file_path = os.path.join(root_dir, f)
							break
					if blend_file_path:
						break
			
			self.status = f"Projekt empfangen: {payload_meta.get('file_count', 0) if payload_meta else 'n/a'} Dateien"
			
			# Schedule blend file load in main thread
			if blend_file_path:
				self.pending_project_load = blend_file_path
				self.status = f"Öffne Projekt: {os.path.basename(blend_file_path)}"
			
			try:
				os.unlink(tmp_zip)
			except Exception:
				pass
			
			return {
				"type": "project_sync_ack",
				"worker_id": self.node_id,
				"ok": True,
				"project_dir": target_dir,
				"blend_file": blend_file_path,
			}
		except Exception as exc:
			self.last_error = f"Projekt-Sync fehlgeschlagen: {exc}"
			return {
				"type": "project_sync_ack",
				"worker_id": self.node_id,
				"ok": False,
				"error": str(exc),
			}

	def _sync_project_to_workers(self, workers, timeout_seconds=30.0):
		"""Start async project sync. Does NOT block. Returns immediately."""
		if not workers:
			return True
		
		# Start async transfer without blocking
		if self._loop:
			asyncio.run_coroutine_threadsafe(
				self._sync_project_to_workers_async(workers, timeout_seconds),
				self._loop
			)
		return True  # Fire-and-forget
	
	async def _sync_project_to_workers_async(self, workers, timeout_seconds=30.0):
		"""Async project sync with real-time progress tracking."""
		try:
			self.sync_active = True
			self.sync_successful = False
			self.sync_start_time = time.time()
			self.sync_progress = {}
			self.project_sync_results = {}
			
			bundle = self._build_project_bundle()
			parts = bundle.get("parts") if isinstance(bundle, dict) and bundle.get("parts") else None
			self.sync_total_bytes = int(bundle.get("total_bytes", 0)) if isinstance(bundle, dict) else 0
			self.sync_total_parts = int(bundle.get("total_parts", 0)) if isinstance(bundle, dict) else 0
			
			if not parts:
				# legacy single-zip support
				zip_path = bundle.get("zip_path")
				if zip_path:
					parts = [
						{
							"zip_path": zip_path,
							"zip_sha256": bundle.get("zip_sha256"),
							"part_index": 0,
							"total_parts": 1,
							"file_count": bundle.get("file_count", 0),
							"total_bytes": bundle.get("total_bytes", 0),
						}
					]
				else:
					self.last_error = "Kein Projektbundle erstellt"
					self.sync_active = False
					return
			
			chunk_size = 128 * 1024
			total_parts = int(parts[0].get("total_parts", len(parts)))
			total_bundle_bytes = sum(int(p.get("total_bytes", 0)) for p in parts)
			self.sync_total_bytes = total_bundle_bytes or self.sync_total_bytes
			self.sync_total_parts = total_parts or self.sync_total_parts
			estimated_timeout = max(float(timeout_seconds), (total_bundle_bytes / float(5 * 1024 * 1024)) + 120.0)
			
			# Initialize progress tracker for all workers
			for wid in workers:
				self.sync_progress[wid] = {
					"worker_id": wid,
					"current_bytes": 0,
					"total_bytes": total_bundle_bytes,
					"part": 0,
					"total_parts": total_parts,
					"status": "waiting",
					"error": None,
					"speed_mbps": 0.0,
				}
			
			async def _send_all_parts_to_worker(worker_id, info, parts_list):
				"""Send all parts to a single worker with progress tracking."""
				if worker_id not in self.sync_progress:
					return
				
				progress = self.sync_progress[worker_id]
				progress["status"] = "connecting"
				progress["total_bytes"] = total_bundle_bytes
				
				for part in parts_list:
					try:
						part_path = part["zip_path"]
						part_idx = int(part.get("part_index", 0))
						file_size = int(part.get("total_bytes", os.path.getsize(part_path)))
						
						progress["part"] = part_idx + 1
						progress["status"] = f"Teil {part_idx+1}/{total_parts}"
						progress["total_bytes"] = total_bundle_bytes
						
						start = {
							"type": "project_sync_start",
							"project_name": part.get("project_name"),
							"blend_file": part.get("blend_file"),
							"zip_sha256": part.get("zip_sha256"),
							"total_size": file_size,
							"chunk_size": chunk_size,
							"part_index": part_idx,
							"total_parts": int(part.get("total_parts", total_parts)),
							"file_count": int(part.get("file_count", 0)),
						}
						await info["socket"].send(json_dumps(start))
						
						# Stream binary chunks with progress
						bytes_sent = 0
						part_start_time = time.time()
						with open(part_path, "rb") as fh:
							while True:
								chunk = fh.read(chunk_size)
								if not chunk:
									break
								await info["socket"].send(chunk)
								bytes_sent += len(chunk)
								progress["current_bytes"] += len(chunk)
								
								# Calculate speed every 512KB
								if bytes_sent % (512 * 1024) < chunk_size:
									elapsed = time.time() - part_start_time
									if elapsed > 0:
										speed_mbps = (bytes_sent / elapsed) / (1024 * 1024)
										progress["speed_mbps"] = speed_mbps
										total_mbps = progress["total_bytes"] / (1024 * 1024)
										eta_sec = (total_mbps - (progress["current_bytes"] / (1024 * 1024))) / max(speed_mbps, 0.1)
										
										self.status = f"Sync: {worker_id[:8]}... Teil {part_idx+1}/{total_parts}: {progress['current_bytes'] // 1024 // 1024}MB / {progress['total_bytes'] // 1024 // 1024}MB @ {speed_mbps:.1f} MB/s"
						
						self.project_sync_results.setdefault(worker_id, {})
						self.project_sync_results[worker_id][part_idx] = {"worker_id": worker_id, "ok": "pending", "part_index": part_idx}
						progress["status"] = f"Teil {part_idx+1}/{total_parts} versendet"
						
					except Exception as exc:
						part_idx = int(part.get("part_index", 0))
						error_msg = str(exc)
						self.project_sync_results.setdefault(worker_id, {})
						self.project_sync_results[worker_id][part_idx] = {"worker_id": worker_id, "ok": False, "error": error_msg, "part_index": part_idx}
						progress["status"] = "Fehler"
						progress["error"] = error_msg
						self.last_error = f"Sync-Fehler für Worker {worker_id[:8]}: {error_msg}"
						return
			
			# Dispatch all worker sends
			tasks = []
			connected_workers = []
			for worker_id in workers:
				info = self.connected_workers.get(worker_id)
				if not info:
					# Mark all parts as failed
					self.sync_progress[worker_id]["status"] = "nicht verbunden"
					self.sync_progress[worker_id]["error"] = "Worker nicht verbunden"
					self.project_sync_results[worker_id] = {}
					for part_idx in range(total_parts):
						self.project_sync_results[worker_id][part_idx] = {
							"worker_id": worker_id,
							"ok": False,
							"error": "Worker nicht verbunden",
							"part_index": part_idx,
						}
					continue
				
				connected_workers.append(worker_id)
				task = asyncio.ensure_future(_send_all_parts_to_worker(worker_id, info, parts))
				tasks.append((worker_id, task))
			
			# Wait for all sends to complete or timeout
			deadline = time.time() + estimated_timeout
			while time.time() < deadline:
				# Check if all workers reached a terminal state for every part
				all_sent = True
				for wid in connected_workers:
					acks = self.project_sync_results.get(wid, {})
					if not isinstance(acks, dict) or len(acks) < total_parts:
						all_sent = False
						break
					if any(entry.get("ok") == "pending" for entry in acks.values()):
						all_sent = False
						break
				
				if all_sent:
					break
				await asyncio.sleep(0.1)
			
			# Cleanup part files
			for part in parts:
				try:
					os.unlink(part["zip_path"])
				except Exception:
					pass
			
			# Check for timeout
			if time.time() >= deadline:
				self.last_error = "Projekt-Sync Timeout: Worker haben nicht rechtzeitig bestätigt"
				self.status = self.last_error
				for wid in self.sync_progress:
					if self.sync_progress[wid]["status"] not in ("not connected", "Fehler"):
						self.sync_progress[wid]["status"] = "Timeout"
				self.sync_active = False
				return
			
			# Check for failures
			failed = []
			error_details = []
			for wid in workers:
				acks = self.project_sync_results.get(wid, {})
				if not isinstance(acks, dict) or len(acks) < total_parts:
					failed.append(wid)
					self.sync_progress[wid]["status"] = "unvollständig"
					error_details.append(f"Worker {wid[:8]}: Incomplete sync (got {len(acks)}/{total_parts} parts)")
					continue
				
				for idx, entry in acks.items():
					if entry.get("ok") is not True:
						failed.append(wid)
						self.sync_progress[wid]["status"] = "Fehler"
						error_msg = entry.get("error", "Unbekannter Fehler")
						error_details.append(f"Worker {wid[:8]} Part {idx}: {error_msg}")
						break
				else:
					# All parts OK
					self.sync_progress[wid]["status"] = "Fertig"
			
			if not failed:
				self.status = f"Projekt-Sync erfolgreich ({len(workers)} Worker)"
				elapsed = time.time() - self.sync_start_time
				self._progress_queue.put(f"Projekt-Sync: {len(workers)} Worker in {elapsed:.1f}s abgeschlossen")
				self.sync_successful = True
			else:
				error_summary = " | ".join(error_details[:3])
				self.last_error = f"Projekt-Sync fehlgeschlagen: {error_summary}"
				self.status = f"Projekt-Sync fehlgeschlagen auf {len(failed)} Workern"
				for wid in failed:
					if wid in self.sync_progress:
						self.sync_progress[wid]["status"] = "Fehler"
				self.sync_successful = False
		
		except Exception as e:
			self.last_error = f"Projekt-Sync Exception: {e}"
			self.status = self.last_error
			self.sync_successful = False
		
		finally:
			self.sync_active = False

	def start_distributed_render(self):
		if self.role != "server":
			self.status = "Starte Server vor Render"
			if not self.force_start_server():
				self.last_error = self.status
				return False

			deadline = time.time() + 3.0
			while time.time() < deadline and self.role != "server":
				time.sleep(0.05)

			if self.role != "server":
				self.last_error = "Server konnte nicht rechtzeitig gestartet werden"
				self.status = self.last_error
				return False

		if self.auto_sync_project:
			workers = list(self.connected_workers.keys())
			if self.sync_active:
				self.pending_render_after_sync = True
				self.status = "Projekt-Sync läuft bereits, Render startet danach"
				return True

			self.pending_render_after_sync = True
			ok = self._sync_project_to_workers(workers, timeout_seconds=60.0)
			if not ok:
				self.pending_render_after_sync = False
				return False
			self.status = "Projekt-Sync läuft, Render startet danach"
			return True

		return self._begin_distributed_render()

	def _begin_distributed_render(self):
		if self.role != "server":
			self.last_error = "Nur der Server kann den verteilten Render starten"
			self.status = self.last_error
			return False

		# Optionally open a render window before starting distributed render
		if self.show_render_window:
			try:
				bpy.ops.wm.window_new()
				self.status = "Render-Fenster geöffnet"
			except Exception as e:
				self.last_error = f"Fenster-Öffnung fehlgeschlagen: {e}"

		scene = _safe_scene()
		if scene is None:
			self.last_error = "Keine aktive Szene"
			return False

		render = scene.render
		final_width = max(1, int(render.resolution_x * (render.resolution_percentage / 100.0)))
		final_height = max(1, int(render.resolution_y * (render.resolution_percentage / 100.0)))

		_, signature = collect_render_signature(scene)
		self.current_render_config = {
			"render_signature": signature,
			"resolution_x": final_width,
			"resolution_y": final_height,
		}
		self.last_integrity = "pending"

		workers = list(self.connected_workers.keys())

		# Calculate grid based on whether server renders or not
		node_count = len(workers) + (1 if self.server_render_tiles else 0)
		total_nodes = max(1, node_count)
		grid_x, grid_y = grid_for_worker_count(total_nodes)
		overlap_px = overlap_pixels(final_width, final_height, self.overlap_percent)
		tiles = generate_tiles(final_width, final_height, grid_x, grid_y, overlap=overlap_px)

		output = bpy.path.abspath(render.filepath)
		if os.path.isdir(output):
			output = os.path.join(output, "distributed_render.png")
		elif not os.path.splitext(output)[1]:
			output = output + ".png"

		self._prepare_output_dirs(output)
		output = os.path.join(self.current_master_dir, os.path.basename(output))

		self.current_render_output = output
		self.pending_jobs = {}
		self.completed_jobs = {}
		self.job_owner = {}
		self.job_attempts = {}
		self.render_plan = []
		self.expected_jobs = len(tiles)
		self.render_start_time = time.time()

		# Build target list (server as MASTER only if server_render_tiles is True)
		targets = []
		if self.server_render_tiles:
			targets.append("MASTER")
		targets.extend(workers)
		
		if not targets:
			self.last_error = "Keine Worker verfügbar und Server-Rendering deaktiviert"
			self.status = self.last_error
			return False
		
		for idx, tile in enumerate(tiles):
			target = targets[idx % len(targets)]
			self.render_plan.append({
				"tile_id": tile["id"],
				"target": target,
				"min_x": tile["min_x"],
				"max_x": tile["max_x"],
				"min_y": tile["min_y"],
				"max_y": tile["max_y"],
				"core_min_x": tile["core_min_x"],
				"core_max_x": tile["core_max_x"],
				"core_min_y": tile["core_min_y"],
				"core_max_y": tile["core_max_y"],
			})
			job = {
				"type": "render_tile",
				"tile_id": tile["id"],
				"tile": tile,
				"render_signature": signature,
			}
			self.pending_jobs[tile["id"]] = job
			self.job_attempts[tile["id"]] = 0
			self.job_owner[tile["id"]] = target

			if target == "MASTER":
				self._task_queue.put({"type": "render_tile", "payload": job, "reply_to": "server_local"})
			else:
				self._send_job_to_worker(target, job)

		self.status = (
			f"Render gestartet mit {len(tiles)} Tiles auf {total_nodes} Maschinen, Overlap {self.overlap_percent:.1f}%"
		)
		return True

	def _send_job_to_worker(self, worker_id, job):
		info = self.connected_workers.get(worker_id)
		if not info:
			self._reassign_tile(job["tile_id"], f"Worker {worker_id} nicht verfuegbar")
			return

		ws = info["socket"]

		async def _send():
			try:
				await ws.send(json_dumps(job))
			except Exception as exc:
				self._reassign_tile(job["tile_id"], f"Sendefehler: {exc}")

		if self._loop:
			asyncio.run_coroutine_threadsafe(_send(), self._loop)

	def _consume_tile_result(self, message):
		tile_id = message.get("tile_id")
		if tile_id not in self.pending_jobs:
			return

		if not message.get("ok"):
			self._reassign_tile(tile_id, message.get("error", "Unbekannter Fehler"))
			return

		tile = message["tile"]
		png_data = base64.b64decode(message["png_base64"])
		temp_dir = self.current_raw_splits_dir or os.path.join(tempfile.gettempdir(), "blender_splitter_received")
		os.makedirs(temp_dir, exist_ok=True)
		path = os.path.join(temp_dir, f"{tile_id}_{uuid.uuid4().hex}.png")
		with open(path, "wb") as fh:
			fh.write(png_data)

		self.completed_jobs[tile_id] = {
			"tile_id": tile_id,
			"path": path,
			"min_x": tile["min_x"],
			"max_x": tile["max_x"],
			"min_y": tile["min_y"],
			"max_y": tile["max_y"],
			"core_min_x": tile["core_min_x"],
			"core_max_x": tile["core_max_x"],
			"core_min_y": tile["core_min_y"],
			"core_max_y": tile["core_max_y"],
		}
		del self.pending_jobs[tile_id]
		self.job_owner.pop(tile_id, None)

		done = len(self.completed_jobs)
		self.status = f"Tiles fertig: {done}/{self.expected_jobs}"
		if done >= self.expected_jobs:
			self._finalize_render()

	def _finalize_render(self):
		if not self.current_render_config:
			return

		try:
			stitch_tiles(
				sorted(
					self.completed_jobs.values(),
					key=lambda tile: (
						int(tile.get("core_min_y", tile.get("min_y", 0))),
						int(tile.get("core_min_x", tile.get("min_x", 0))),
						str(tile.get("tile_id", "")),
					),
				),
				self.current_render_config["resolution_x"],
				self.current_render_config["resolution_y"],
				self.current_render_output,
			)
			self.last_duration_seconds = time.time() - self.render_start_time
			self.last_integrity = "ok"
			self.status = (
				f"Render abgeschlossen in {self.last_duration_seconds:.2f}s - {self.current_render_output}"
			)
		except Exception as exc:
			self.last_error = f"Stitching fehlgeschlagen: {exc}"
			self.status = self.last_error
			traceback.print_exc()

	def _reassign_jobs_from_worker(self, worker_id):
		for tile_id, owner in list(self.job_owner.items()):
			if owner == worker_id and tile_id in self.pending_jobs:
				self._reassign_tile(tile_id, f"Worker {worker_id} getrennt")

	def _reassign_tile(self, tile_id, reason):
		if tile_id not in self.pending_jobs:
			return

		attempt = self.job_attempts.get(tile_id, 0) + 1
		self.job_attempts[tile_id] = attempt
		job = self.pending_jobs[tile_id]
		prev_owner = self.job_owner.get(tile_id)

		if attempt > self.max_retries:
			self.last_error = f"Tile {tile_id} nach {attempt - 1} Retries fehlgeschlagen: {reason}"
			self.status = self.last_error
			self.last_integrity = "fehlgeschlagen"
			return

		candidates = [wid for wid in self.connected_workers.keys() if wid != prev_owner]
		target = random.choice(candidates) if candidates else "MASTER"
		self.job_owner[tile_id] = target

		if target == "MASTER":
			self._task_queue.put({"type": "render_tile", "payload": job, "reply_to": "server_local"})
		else:
			self._send_job_to_worker(target, job)

		self.status = f"Tile {tile_id} neu zugewiesen ({attempt}/{self.max_retries}): {reason}"

	def cancel_render(self):
		"""Abort the current distributed render: clear pending jobs and notify status."""
		if not self.current_render_config:
			self.status = "Kein verteilter Render aktiv"
			return False

		# clear pending and job metadata
		self.pending_jobs.clear()
		self.job_owner.clear()
		self.job_attempts.clear()
		self.expected_jobs = 0
		self.current_render_config = None
		self.current_render_output = ""
		self.last_integrity = "abgebrochen"
		self.status = "Verteilter Render abgebrochen"
		return True

	def kick_worker(self, worker_id):
		"""Disconnect a single worker by id (best-effort)."""
		info = self.connected_workers.get(worker_id)
		if not info:
			self.status = f"Worker {worker_id} nicht gefunden"
			return False
		ws = info.get("socket")
		try:
			if self._loop and ws is not None:
				asyncio.run_coroutine_threadsafe(ws.close(), self._loop)
		except Exception:
			pass
		if worker_id in self.connected_workers:
			del self.connected_workers[worker_id]
		self.status = f"Worker {worker_id} getrennt"
		return True

	def kick_all_workers(self):
		"""Disconnect all workers immediately."""
		ids = list(self.connected_workers.keys())
		for wid in ids:
			try:
				self.kick_worker(wid)
			except Exception:
				pass
		self.status = f"Alle Worker gekickt ({len(ids)})"
		return True

	def run_integrity_check(self, timeout_seconds=5.0):
		if self.role != "server":
			self.last_error = "Integrity Check nur auf Server moeglich"
			return False

		scene = _safe_scene()
		if scene is None:
			self.last_error = "Keine aktive Szene"
			return False

		_, signature = collect_render_signature(scene)
		workers = list(self.connected_workers.keys())
		if not workers:
			self.last_integrity = "ok"
			self.status = "Integrity Check OK (nur Master aktiv)"
			return True

		self.integrity_probe_results = {}

		async def _broadcast_probe():
			payload = {"type": "integrity_probe", "render_signature": signature}
			for worker_id in workers:
				info = self.connected_workers.get(worker_id)
				if not info:
					continue
				try:
					await info["socket"].send(json_dumps(payload))
				except Exception as exc:
					self.integrity_probe_results[worker_id] = {
						"worker_id": worker_id,
						"ok": False,
						"error": str(exc),
					}

		if self._loop:
			asyncio.run_coroutine_threadsafe(_broadcast_probe(), self._loop)

		deadline = time.time() + float(timeout_seconds)
		while time.time() < deadline:
			if len(self.integrity_probe_results) >= len(workers):
				break
			time.sleep(0.1)

		ok = True
		for worker_id in workers:
			entry = self.integrity_probe_results.get(worker_id)
			if not entry or not entry.get("ok"):
				ok = False
				break

		self.last_integrity = "ok" if ok else "fehlgeschlagen"
		if ok:
			self.status = f"Integrity Check OK auf {len(workers)} Workern"
		else:
			self.status = "Integrity Check fehlgeschlagen"
		return ok

	def auto_install_requirements(self, only_modules=None):
		"""Installs missing runtime packages in Blender Python (best effort)."""
		required = {
			"websockets": "websockets>=12.0",
			"PIL": "pillow>=10.0.0",
			"numpy": "numpy>=1.26.0",
		}

		if only_modules:
			required = {k: v for k, v in required.items() if k in set(only_modules)}

		missing = []
		for module_name, package_name in required.items():
			try:
				importlib.import_module(module_name)
			except Exception:
				missing.append(package_name)

		if not missing:
			self.status = "Requirements bereits installiert"
			return True

		self.status = f"Installiere Requirements: {', '.join(missing)}"
		try:
			subprocess.run([sys.executable, "-m", "ensurepip", "--upgrade"], check=False)
			subprocess.run([sys.executable, "-m", "pip", "install", *missing], check=True)
			if "websockets" in required:
				_load_websockets_module()
			self.status = "Requirements erfolgreich installiert"
			return True
		except Exception as exc:
			self.last_error = f"Auto-Install fehlgeschlagen: {exc}"
			self.status = self.last_error
			return False


_MANAGER = DistributedRenderManager()


def manager():
	return _MANAGER