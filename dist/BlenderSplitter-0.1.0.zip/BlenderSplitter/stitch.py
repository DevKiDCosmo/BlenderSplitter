import os


def _feather_line(length, low_feather, high_feather, np):
	line = np.ones((int(length),), dtype=np.float32)
	lf = max(0, int(low_feather))
	hf = max(0, int(high_feather))
	if lf > 0:
		line[:lf] = np.linspace(0.0, 1.0, lf, endpoint=True, dtype=np.float32)
	if hf > 0:
		line[-hf:] = np.minimum(
			line[-hf:],
			np.linspace(1.0, 0.0, hf, endpoint=True, dtype=np.float32),
		)
	return line


def stitch_tiles(tile_results, resolution_x, resolution_y, output_path):
	"""Stitches tile images into one final image and writes to output_path."""
	try:
		from PIL import Image
	except ImportError as exc:
		raise RuntimeError(
			"Pillow ist nicht installiert. Bitte `pip install pillow` im Blender-Python ausfuehren."
		) from exc

	try:
		import numpy as np
	except ImportError:
		np = None

	width = int(resolution_x)
	height = int(resolution_y)

	def _sort_key(tile):
		return (
			int(tile.get("core_min_y", tile.get("min_y", 0))),
			int(tile.get("core_min_x", tile.get("min_x", 0))),
			str(tile.get("tile_id", tile.get("id", ""))),
		)

	tile_results = sorted(tile_results, key=_sort_key)

	if np is None:
		# Fallback without numpy: place only core regions to avoid overlap seams.
		final_img = Image.new("RGBA", (width, height))
		for tile in tile_results:
			path = tile["path"]
			if not os.path.exists(path):
				raise RuntimeError(f"Tile-Datei fehlt: {path}")
			with Image.open(path) as img:
				img = img.convert("RGBA")
				offset_x = int(tile["core_min_x"] - tile["min_x"])
				offset_y = int(tile["core_min_y"] - tile["min_y"])
				core_w = int(tile["core_max_x"] - tile["core_min_x"])
				core_h = int(tile["core_max_y"] - tile["core_min_y"])
				core = img.crop((offset_x, offset_y, offset_x + core_w, offset_y + core_h))
				final_img.paste(core, (int(tile["core_min_x"]), int(tile["core_min_y"])))

		os.makedirs(os.path.dirname(output_path), exist_ok=True)
		final_img.save(output_path)
		return output_path

	acc_rgb = np.zeros((height, width, 3), dtype=np.float32)
	acc_w = np.zeros((height, width), dtype=np.float32)

	for tile in tile_results:
		path = tile["path"]
		if not os.path.exists(path):
			raise RuntimeError(f"Tile-Datei fehlt: {path}")

		with Image.open(path) as img:
			img = img.convert("RGB")
			box = (
				int(tile["min_x"]),
				int(tile["min_y"]),
				int(tile["max_x"]),
				int(tile["max_y"]),
			)
			expected_w = box[2] - box[0]
			expected_h = box[3] - box[1]

			if img.size != (expected_w, expected_h):
				img = img.resize((expected_w, expected_h))

			tile_arr = np.asarray(img, dtype=np.float32)
			left_feather = int(tile["core_min_x"] - tile["min_x"])
			right_feather = int(tile["max_x"] - tile["core_max_x"])
			bottom_feather = int(tile["core_min_y"] - tile["min_y"])
			top_feather = int(tile["max_y"] - tile["core_max_y"])

			wx = _feather_line(expected_w, left_feather, right_feather, np)
			wy = _feather_line(expected_h, bottom_feather, top_feather, np)
			w = np.outer(wy, wx)

			x0, y0 = box[0], box[1]
			x1, y1 = box[2], box[3]
			acc_rgb[y0:y1, x0:x1, :] += tile_arr * w[:, :, None]
			acc_w[y0:y1, x0:x1] += w

	acc_w = np.maximum(acc_w, 1e-6)
	out = (acc_rgb / acc_w[:, :, None]).clip(0, 255).astype(np.uint8)
	final_img = Image.fromarray(out, mode="RGB").convert("RGBA")

	os.makedirs(os.path.dirname(output_path), exist_ok=True)
	final_img.save(output_path)
	return output_path
