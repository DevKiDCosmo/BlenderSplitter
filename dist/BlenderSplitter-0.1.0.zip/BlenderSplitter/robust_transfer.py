import base64

from .robust_protocol import (
	MSG_TILE_RESULT,
	MSG_TILE_RESULT_CHUNK,
	MSG_TILE_RESULT_COMPLETE,
	MSG_TILE_RESULT_START,
	build_tile_result_chunk,
	build_tile_result_complete,
	build_tile_result_start,
)


class TileResultChunker:
	def __init__(self, chunk_size=512 * 1024, inline_limit=1024 * 1024):
		self.chunk_size = int(chunk_size)
		self.inline_limit = int(inline_limit)

	def needs_chunking(self, png_b64):
		return len(png_b64 or "") > self.inline_limit

	def build_messages(self, result, transfer_id):
		png_b64 = result.get("png_base64") or ""
		raw = base64.b64decode(png_b64)
		total_chunks = (len(raw) + self.chunk_size - 1) // self.chunk_size
		msgs = [
			build_tile_result_start(
				transfer_id=transfer_id,
				tile_id=result.get("tile_id"),
				worker_id=result.get("worker_id"),
				tile=result.get("tile"),
				total_size=len(raw),
				total_chunks=total_chunks,
			)
		]
		for idx in range(total_chunks):
			start = idx * self.chunk_size
			end = min(len(raw), start + self.chunk_size)
			chunk_b64 = base64.b64encode(raw[start:end]).decode("ascii")
			msgs.append(build_tile_result_chunk(transfer_id=transfer_id, index=idx, data_b64=chunk_b64))
		msgs.append(
			build_tile_result_complete(
				transfer_id=transfer_id,
				tile_id=result.get("tile_id"),
				worker_id=result.get("worker_id"),
				tile=result.get("tile"),
				ok=result.get("ok", True),
			)
		)
		return msgs


class TileResultAssembler:
	def __init__(self):
		self._incoming = {}

	def handle(self, msg):
		msg_type = msg.get("type")
		if msg_type == MSG_TILE_RESULT:
			return msg

		if msg_type == MSG_TILE_RESULT_START:
			transfer_id = msg.get("transfer_id")
			if transfer_id:
				self._incoming[transfer_id] = {
					"tile_id": msg.get("tile_id"),
					"worker_id": msg.get("worker_id"),
					"tile": msg.get("tile"),
					"total_chunks": int(msg.get("total_chunks", 0)),
					"chunks": {},
				}
			return None

		if msg_type == MSG_TILE_RESULT_CHUNK:
			transfer_id = msg.get("transfer_id")
			entry = self._incoming.get(transfer_id)
			if entry is not None:
				try:
					entry["chunks"][int(msg.get("index", 0))] = msg.get("data", "")
				except Exception:
					pass
			return None

		if msg_type == MSG_TILE_RESULT_COMPLETE:
			transfer_id = msg.get("transfer_id")
			entry = self._incoming.pop(transfer_id, None)
			if entry is None:
				return None
			ordered = [entry["chunks"].get(i, "") for i in range(entry.get("total_chunks", 0))]
			return {
				"type": MSG_TILE_RESULT,
				"tile_id": entry.get("tile_id"),
				"worker_id": entry.get("worker_id"),
				"tile": entry.get("tile"),
				"ok": bool(msg.get("ok", True)),
				"png_base64": "".join(ordered),
			}

		return None