import hashlib
import json
import math


def generate_tiles(res_x, res_y, tiles_x, tiles_y, overlap=0):
    tiles = []
    overlap = max(0, int(overlap))
    tile_width = res_x // tiles_x
    tile_height = res_y // tiles_y

    for y in range(tiles_y):
        for x in range(tiles_x):
            core_min_x = x * tile_width
            core_max_x = res_x if x == (tiles_x - 1) else (x + 1) * tile_width
            core_min_y = y * tile_height
            core_max_y = res_y if y == (tiles_y - 1) else (y + 1) * tile_height

            min_x = max(0, core_min_x - overlap)
            max_x = min(res_x, core_max_x + overlap)

            min_y = max(0, core_min_y - overlap)
            max_y = min(res_y, core_max_y + overlap)

            tiles.append({
                "id": f"{x}_{y}",
                "min_x": min_x,
                "max_x": max_x,
                "min_y": min_y,
                "max_y": max_y,
                "core_min_x": core_min_x,
                "core_max_x": core_max_x,
                "core_min_y": core_min_y,
                "core_max_y": core_max_y,
                "status": "pending"
            })
        
    return tiles


def grid_for_worker_count(worker_count):
    """Returns a near-square grid that can cover the worker count."""
    worker_count = max(1, int(worker_count))
    tiles_x = int(math.floor(math.sqrt(worker_count)))
    tiles_y = int(math.ceil(worker_count / max(1, tiles_x)))
    while tiles_x * tiles_y < worker_count:
        tiles_x += 1
    return max(1, tiles_x), max(1, tiles_y)


def overlap_pixels(resolution_x, resolution_y, overlap_percent):
    """Converts overlap percentage to pixels, clamped to 2-5%."""
    pct = float(overlap_percent)
    pct = max(2.0, min(5.0, pct))
    ref = min(int(resolution_x), int(resolution_y))
    return max(1, int(round(ref * (pct / 100.0))))


def collect_render_signature(scene):
    render = scene.render
    camera = scene.camera
    cycles = getattr(scene, "cycles", None)

    payload = {
        "engine": render.engine,
        "resolution_x": render.resolution_x,
        "resolution_y": render.resolution_y,
        "resolution_percentage": render.resolution_percentage,
        "pixel_aspect_x": render.pixel_aspect_x,
        "pixel_aspect_y": render.pixel_aspect_y,
        "film_transparent": render.film_transparent,
        "image_settings": {
            "file_format": render.image_settings.file_format,
            "color_mode": render.image_settings.color_mode,
            "color_depth": render.image_settings.color_depth,
            "color_management": render.image_settings.color_management,
        },
        "camera": {
            "name": camera.name if camera else None,
            "lens": camera.data.lens if camera else None,
            "sensor_fit": camera.data.sensor_fit if camera else None,
            "shift_x": camera.data.shift_x if camera else None,
            "shift_y": camera.data.shift_y if camera else None,
        },
        "cycles": {
            "samples": getattr(cycles, "samples", None),
            "preview_samples": getattr(cycles, "preview_samples", None),
            "seed": getattr(cycles, "seed", None),
            "use_adaptive_sampling": getattr(cycles, "use_adaptive_sampling", None),
            "device": getattr(cycles, "device", None),
            "feature_set": getattr(cycles, "feature_set", None),
        },
    }

    body = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    signature = hashlib.sha256(body.encode("utf-8")).hexdigest()
    return payload, signature