import json


MSG_TILE_RESULT = "tile_result"
MSG_TILE_RESULT_START = "tile_result_start"
MSG_TILE_RESULT_CHUNK = "tile_result_chunk"
MSG_TILE_RESULT_COMPLETE = "tile_result_complete"


def dumps_compact(payload):
	return json.dumps(payload, separators=(",", ":"), sort_keys=True)


def build_tile_result_start(transfer_id, tile_id, worker_id, tile, total_size, total_chunks):
	return {
		"type": MSG_TILE_RESULT_START,
		"transfer_id": transfer_id,
		"tile_id": tile_id,
		"worker_id": worker_id,
		"tile": tile,
		"total_size": int(total_size),
		"total_chunks": int(total_chunks),
	}


def build_tile_result_chunk(transfer_id, index, data_b64):
	return {
		"type": MSG_TILE_RESULT_CHUNK,
		"transfer_id": transfer_id,
		"index": int(index),
		"data": data_b64,
	}


def build_tile_result_complete(transfer_id, tile_id, worker_id, tile, ok=True):
	return {
		"type": MSG_TILE_RESULT_COMPLETE,
		"transfer_id": transfer_id,
		"tile_id": tile_id,
		"worker_id": worker_id,
		"tile": tile,
		"ok": bool(ok),
	}