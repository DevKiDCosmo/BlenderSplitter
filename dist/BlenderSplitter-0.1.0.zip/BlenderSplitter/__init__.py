bl_info = {
    "name": "Distributed Tile Renderer",
    "blender": (5, 1, 0),
    "category": "Render",
    "version": (0, 1, 0),
    "author": "BlenderSplitter",
    "description": "Distributed tile rendering over WebSocket with auto discovery",
}

import bpy
import threading
from . import ui
from .worker import manager


def _startup_auto_connect():
    mgr = manager()
    threading.Thread(target=mgr.auto_install_requirements, daemon=True).start()
    if not mgr.started:
        # Uses default settings until user changes values in panel.
        mgr.configure("0.0.0.0", 8765, 8766, 3.0, 3, True)
        mgr.start()
    return None


def register():
    ui.register()
    bpy.app.timers.register(_startup_auto_connect, first_interval=1.0, persistent=True)


def unregister():
    manager().stop()
    ui.unregister()