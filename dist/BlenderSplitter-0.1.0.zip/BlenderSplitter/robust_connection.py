class ReconnectController:
	def __init__(self, rediscover_after=3, self_host_after=8, max_sleep=2.5):
		self.rediscover_after = int(rediscover_after)
		self.self_host_after = int(self_host_after)
		self.max_sleep = float(max_sleep)
		self.failures = 0

	def reset(self):
		self.failures = 0

	def on_failure(self):
		self.failures += 1
		return self.failures

	def should_rediscover(self):
		return self.failures >= self.rediscover_after

	def should_self_host(self):
		return self.failures >= self.self_host_after

	def sleep_seconds(self):
		return min(self.max_sleep, 0.5 + 0.3 * self.failures)