import json
import socket
import threading
import time

DISCOVERY_MAGIC = "BLENDER_SPLITTER_DISCOVERY_V1"
DISCOVERY_REPLY = "BLENDER_SPLITTER_SERVER_V1"


def json_dumps(data):
    return json.dumps(data, separators=(",", ":"), sort_keys=True)


def _best_local_ip():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        sock.close()


def discover_server(discovery_port, timeout=1.5):
    """Broadcasts a discovery ping and returns (host, port) of first server found."""
    msg = DISCOVERY_MAGIC.encode("utf-8")
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.settimeout(timeout)
    try:
        targets = [
            ("255.255.255.255", int(discovery_port)),
            ("<broadcast>", int(discovery_port)),
            ("127.0.0.1", int(discovery_port)),
        ]
        for target in targets:
            try:
                sock.sendto(msg, target)
            except OSError:
                continue

        deadline = time.time() + timeout
        while time.time() < deadline:
            data, addr = sock.recvfrom(1024)
            decoded = data.decode("utf-8", errors="ignore")
            if not decoded.startswith(DISCOVERY_REPLY):
                continue
            payload = decoded[len(DISCOVERY_REPLY) :]
            details = json.loads(payload)

            # Use sender address as authoritative fallback if host is loopback/invalid.
            advertised_host = details.get("host")
            if advertised_host in (None, "", "127.0.0.1", "localhost", "0.0.0.0", "::1"):
                host = addr[0]
            else:
                host = advertised_host

            return host, int(details["port"])
    except OSError:
        return None
    except (json.JSONDecodeError, KeyError, ValueError):
        return None
    finally:
        sock.close()
    return None


class DiscoveryResponder:
    """UDP responder so workers can auto-discover the active server."""

    def __init__(self, discovery_port, websocket_port):
        self.discovery_port = int(discovery_port)
        self.websocket_port = int(websocket_port)
        self.host = _best_local_ip()
        self._thread = None
        self._stop_event = threading.Event()

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=1.0)

    def _run(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(("", self.discovery_port))
            sock.settimeout(0.5)

            while not self._stop_event.is_set():
                try:
                    data, addr = sock.recvfrom(1024)
                except socket.timeout:
                    continue
                except OSError:
                    break

                if data.decode("utf-8", errors="ignore") != DISCOVERY_MAGIC:
                    continue

                response = (
                    DISCOVERY_REPLY
                    + json_dumps({"host": self.host, "port": self.websocket_port})
                ).encode("utf-8")
                try:
                    sock.sendto(response, addr)
                except OSError:
                    continue
        finally:
            sock.close()